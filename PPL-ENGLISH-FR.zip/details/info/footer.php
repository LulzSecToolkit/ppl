            <div class="foot-pay">
                <center>
                    <a href="#">About	</a>
                    <a href="#">Public Policyy</a>
                    <a href="#">Legal</a>
                    <a href="#">Privacy</a>                
                </center>            
            </div>